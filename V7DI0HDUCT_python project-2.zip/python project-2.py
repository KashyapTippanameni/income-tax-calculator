income=int(input())
#here we have taken an input and coverted that input into the integer
discounted_amount=(income-50000)
#here we have taken an variable discounted_amount to reduce 500000 from income
if income <=250000:
    print("Tax=0")
#now we have taken income <=250000 and given command if if condition is true then print Tax=0
if income >250000 and income<500000:
    print(int((discounted_amount-250000)*5/100))
# at here we can calculate amount between 250000 and 500000
if income >500000 and income<=750000:
    print(int((discounted_amount-500000)*10/100)+(250000*(5/100)) )
# at here we can calculate amount between 500000 and 750000
if income >750000 and income<=1000000:
    print(int((discounted_amount-750000)*(15/100)+(250000*(5/100))+(250000*(10/100)) ))
# at here we can calculate amount between 750000 and 1000000
if income >1000000 and income<=1250000:
    print(int((discounted_amount-1000000)*(20/100)+(250000*(5/100))+(250000*(10/100))+(250000*(15/100)) ))
# at here we can calculate amount between 1000000 and 1250000
if income >1250000 and income<=1500000:
    print(int((discounted_amount-1250000)*(25/100)+(250000*(5/100))+(250000*(10/100))+(250000*(15/100))+(250000*(20/100))) )
# at here we can calculate amount between 1250000 and 1500000
if income >1500000:
    print(int((discounted_amount-1500000)*(30/100)+(250000*(5/100))+(250000*(10/100))+(250000*(15/100)+(250000*(20/100))+(250000*(25/100))
    )))
# at here we can calculate amount greater than 1500000